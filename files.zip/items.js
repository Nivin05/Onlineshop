// Update your items here!
const items = [
  {
    name: "Handmade Necklace",
    price: "₹499",
    image: "https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=400&q=80"
  },
  {
    name: "Wooden Sunglasses",
    price: "₹799",
    image: "https://images.unsplash.com/photo-1465101046530-73398c7f28ca?auto=format&fit=crop&w=400&q=80"
  },
  {
    name: "Leather Wallet",
    price: "₹599",
    image: "https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=400&q=80"
  }
  // Add more items as needed
];